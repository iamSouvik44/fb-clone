export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyDQJ6BLrcl1FhA0mHbh51w59aVz-busFoo',
    authDomain: 'facebook-clone-b97c7.firebaseapp.com',
    databaseURL: 'https://facebook-clone-b97c7.firebaseio.com',
    projectId: 'facebook-clone-b97c7',
    storageBucket: 'facebook-clone-b97c7.appspot.com',
    messagingSenderId: '540147954872',
    appId: '1:540147954872:web:337c26732d455f157b704d'
  }
};
